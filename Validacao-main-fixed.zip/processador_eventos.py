"""
Consolidador de Relatório de Status dos Eventos Periódicos - eSocial.
Processa arquivos .xlsx com múltiplos blocos de empresas e gera relatório consolidado.
"""

from __future__ import annotations

import re
import unicodedata
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils.dataframe import dataframe_to_rows


class ProcessadorEventosPeriodicos:
    def __init__(self, arquivo_entrada):
        self.arquivo_entrada = arquivo_entrada
        self.dados_raw: Optional[pd.DataFrame] = None
        self.dados_consolidados: pd.DataFrame = pd.DataFrame()
        self.blocos_encontrados: List[int] = []
        self.estatisticas: Dict = {}

    def limpar_nome_empresa(self, nome: str) -> Optional[str]:
        if pd.isna(nome):
            return None
        nome_limpo = re.sub(r"^\d+\s*-\s*", "", str(nome).strip())
        return nome_limpo if nome_limpo else None

    def extrair_digitos(self, texto: str) -> Optional[str]:
        if pd.isna(texto):
            return None
        return re.sub(r"\D", "", str(texto))

    def formatar_cpf(self, cpf: str) -> Optional[str]:
        digitos = self.extrair_digitos(cpf)
        if not digitos:
            return None
        digitos = digitos[:11].rjust(11, "0")
        return f"{digitos[:3]}.{digitos[3:6]}.{digitos[6:9]}-{digitos[9:]}"

    def formatar_cnpj(self, cnpj: str) -> Optional[str]:
        digitos = self.extrair_digitos(cnpj)
        if not digitos:
            return None
        digitos = digitos[:14].rjust(14, "0")
        return f"{digitos[:2]}.{digitos[2:5]}.{digitos[5:8]}/{digitos[8:12]}-{digitos[12:]}"

    def formatar_competencia(self, valor) -> Optional[str]:
        if pd.isna(valor):
            return None

        dt = pd.to_datetime(valor, errors="coerce")
        if pd.notna(dt):
            return f"{dt.year:04d}-{dt.month:02d}"

        return str(valor)

    def identificar_blocos_empresa(self) -> List[int]:
        assert self.dados_raw is not None
        return self.dados_raw.index[
            self.dados_raw.apply(
                lambda r: r.astype(str).str.contains(
                    "RELAÇÃO DE STATUS DOS EVENTOS PERIÓDICOS",
                    case=False,
                    na=False,
                )
            ).any(axis=1)
        ].tolist()

    def extrair_codigo_empresa(self, valor) -> Optional[str]:
        if pd.isna(valor):
            return None

        texto = str(valor).strip()
        match = re.match(r"^\s*(\d+)", texto)
        if not match:
            return None
        return match.group(1)

    def extrair_dados_empresa(
        self, inicio_bloco: int
    ) -> Tuple[Optional[str], Optional[str], Optional[str]]:
        assert self.dados_raw is not None

        empresa = None
        cnpj = None
        codigo_empresa = None
        for idx in range(max(0, inicio_bloco - 10), inicio_bloco + 1):
            linha_texto = str(self.dados_raw.iloc[idx, 0])

            if "Empresa" in linha_texto:
                empresa_raw = self.dados_raw.iloc[idx, 2]
                empresa = self.limpar_nome_empresa(empresa_raw)
                codigo_empresa = self.extrair_codigo_empresa(empresa_raw)
            if "CNPJ" in linha_texto:
                cnpj = self.formatar_cnpj(self.dados_raw.iloc[idx, 2])

        return empresa, cnpj, codigo_empresa

    def extrair_cabecalho(self, inicio_bloco: int, fim_bloco: int) -> Optional[int]:
        assert self.dados_raw is not None

        for idx in range(inicio_bloco, min(inicio_bloco + 12, fim_bloco)):
            if self.dados_raw.iloc[idx].astype(str).str.contains(
                "Código Empregado", case=False, na=False
            ).any():
                return idx
        return None

    def _competencia_para_ordem(self, competencia: Optional[str]) -> Tuple[int, int]:
        if not competencia:
            return (0, 0)

        texto = str(competencia).strip()
        match_yyyy_mm = re.match(r"^(\d{4})-(\d{2})$", texto)
        if match_yyyy_mm:
            return (int(match_yyyy_mm.group(1)), int(match_yyyy_mm.group(2)))

        match_mm_yy = re.match(r"^(\d{2})/(\d{2})$", texto)
        if match_mm_yy:
            return (2000 + int(match_mm_yy.group(2)), int(match_mm_yy.group(1)))

        match_mm_yyyy = re.match(r"^(\d{2})/(\d{4})$", texto)
        if match_mm_yyyy:
            return (int(match_mm_yyyy.group(2)), int(match_mm_yyyy.group(1)))

        return (0, 0)

    def _calcular_status(self, df: pd.DataFrame) -> pd.Series:
        maior_competencia = None
        if not df.empty:
            competencias_validas = [
                c
                for c in df["Competência"].dropna().tolist()
                if self._competencia_para_ordem(c) != (0, 0)
            ]
            if competencias_validas:
                maior_competencia = max(competencias_validas, key=self._competencia_para_ordem)

        def status_linha(linha):
            remuneracao_validada = str(linha["Remuneração"]).strip().lower() == "validado"
            pagamento_texto = str(linha["Pagamento"]).strip().lower()
            pagamento_validado = pagamento_texto == "validado"
            pagamento_em_branco = pagamento_texto in {"", "nan", "none", "nat"}

            if remuneracao_validada and pagamento_validado:
                return "Validado"

            if (
                remuneracao_validada
                and maior_competencia is not None
                and linha["Competência"] == maior_competencia
                and pagamento_em_branco
            ):
                return "Validado"

            return "Invalidado"

        return df.apply(status_linha, axis=1)

    def _normalizar_texto(self, valor, remover_prefixo_numerico: bool = False) -> str:
        if pd.isna(valor):
            return ""

        texto = str(valor).strip().upper()
        if remover_prefixo_numerico:
            texto = re.sub(r"^\d+\s*[-–—]?\s*", "", texto)

        texto = unicodedata.normalize("NFKD", texto)
        texto = "".join(ch for ch in texto if not unicodedata.combining(ch))
        return re.sub(r"\s+", " ", texto)

    def _normalizar_codigo(self, valor) -> str:
        if pd.isna(valor):
            return ""

        codigo = str(valor).strip()
        if re.fullmatch(r"\d+\.0", codigo):
            codigo = codigo[:-2]
        return codigo

    def marcar_afastados(self, df_afastados: pd.DataFrame):
        """
        Marca registros como Afastado com base em lista externa.
        A lista deve conter, no mínimo:
          - nome da empresa
          - código do empregado
          - nome do empregado
        """
        if self.dados_consolidados.empty or df_afastados.empty:
            return

        normalizar_nome_coluna = lambda c: re.sub(r"[^a-z0-9]", "", str(c).lower())
        mapa_colunas = {normalizar_nome_coluna(c): c for c in df_afastados.columns}

        col_empresa = (
            mapa_colunas.get("empresa")
            or mapa_colunas.get("nomeempresa")
            or mapa_colunas.get("razaosocial")
        )
        col_codigo_empresa = (
            mapa_colunas.get("codigoempresa")
            or mapa_colunas.get("codempresa")
            or mapa_colunas.get("empresaid")
        )
        col_codigo = (
            mapa_colunas.get("codigofuncionario")
            or mapa_colunas.get("codigoempregado")
            or mapa_colunas.get("codigocolaborador")
            or mapa_colunas.get("codigo")
            or mapa_colunas.get("matricula")
        )
        col_nome = (
            mapa_colunas.get("funcionario")
            or mapa_colunas.get("nomefuncionario")
            or mapa_colunas.get("nomeempregado")
            or mapa_colunas.get("nome")
            or mapa_colunas.get("colaborador")
        )

        chave_por_codigo = bool(col_codigo_empresa and col_codigo)
        chave_por_texto = bool(col_empresa and col_codigo and col_nome)
        if not (chave_por_codigo or chave_por_texto):
            return

        colunas_base = [col_codigo]
        if col_empresa:
            colunas_base.append(col_empresa)
        if col_nome:
            colunas_base.append(col_nome)
        if col_codigo_empresa:
            colunas_base.append(col_codigo_empresa)

        afastados = df_afastados[colunas_base].copy()
        if col_empresa:
            afastados["empresa"] = df_afastados[col_empresa]
        else:
            afastados["empresa"] = ""
        if col_nome:
            afastados["nome"] = df_afastados[col_nome]
        else:
            afastados["nome"] = ""
        afastados["codigo"] = df_afastados[col_codigo]
        if col_codigo_empresa:
            afastados["codigo_empresa"] = df_afastados[col_codigo_empresa]
        else:
            afastados["codigo_empresa"] = ""
        afastados["empresa_key"] = afastados["empresa"].apply(
            lambda v: self._normalizar_texto(v, remover_prefixo_numerico=True)
        )
        afastados["codigo_empresa_key"] = afastados["codigo_empresa"].apply(
            self._normalizar_codigo
        )
        afastados["codigo_key"] = afastados["codigo"].apply(self._normalizar_codigo)
        afastados["nome_key"] = afastados["nome"].apply(self._normalizar_texto)

        base = self.dados_consolidados.copy()
        base["empresa_key"] = base["Empresa"].apply(
            lambda v: self._normalizar_texto(v, remover_prefixo_numerico=True)
        )
        base["codigo_empresa_key"] = base["Código Empresa"].apply(self._normalizar_codigo)
        base["codigo_key"] = base["Código Empregado"].apply(self._normalizar_codigo)
        base["nome_key"] = base["Nome"].apply(self._normalizar_texto)

        if col_codigo_empresa:
            chaves_afastados = set(
                afastados.apply(
                    lambda r: (r["codigo_empresa_key"], r["codigo_key"]),
                    axis=1,
                ).tolist()
            )
            mascara = base.apply(
                lambda r: (r["codigo_empresa_key"], r["codigo_key"])
                in chaves_afastados,
                axis=1,
            )
        else:
            chaves_afastados = set(
                afastados.apply(
                    lambda r: (r["empresa_key"], r["codigo_key"], r["nome_key"]),
                    axis=1,
                ).tolist()
            )
            mascara = base.apply(
                lambda r: (r["empresa_key"], r["codigo_key"], r["nome_key"])
                in chaves_afastados,
                axis=1,
            )
        self.dados_consolidados.loc[mascara, "Status"] = "Afastado"

    def marcar_por_lista(self, df_lista: pd.DataFrame, status: str):
        """
        Marca registros com um status customizado com base em lista externa.
        A lista deve conter, no mínimo:
          - código da empresa e código do empregado
        ou:
          - nome da empresa, código do empregado e nome do empregado
        """
        if self.dados_consolidados.empty or df_lista.empty:
            return

        normalizar_nome_coluna = lambda c: re.sub(r"[^a-z0-9]", "", str(c).lower())
        mapa_colunas = {normalizar_nome_coluna(c): c for c in df_lista.columns}

        col_empresa = (
            mapa_colunas.get("empresa")
            or mapa_colunas.get("nomeempresa")
            or mapa_colunas.get("razaosocial")
        )
        col_codigo_empresa = (
            mapa_colunas.get("codigoempresa")
            or mapa_colunas.get("codempresa")
            or mapa_colunas.get("empresaid")
        )
        col_codigo = (
            mapa_colunas.get("codigofuncionario")
            or mapa_colunas.get("codigoempregado")
            or mapa_colunas.get("codigocolaborador")
            or mapa_colunas.get("codigo")
            or mapa_colunas.get("matricula")
        )
        col_nome = (
            mapa_colunas.get("funcionario")
            or mapa_colunas.get("nomefuncionario")
            or mapa_colunas.get("nomeempregado")
            or mapa_colunas.get("nome")
            or mapa_colunas.get("colaborador")
        )

        chave_por_codigo = bool(col_codigo_empresa and col_codigo)
        chave_por_texto = bool(col_empresa and col_codigo and col_nome)
        if not (chave_por_codigo or chave_por_texto):
            return

        colunas_base = [col_codigo]
        if col_empresa:
            colunas_base.append(col_empresa)
        if col_nome:
            colunas_base.append(col_nome)
        if col_codigo_empresa:
            colunas_base.append(col_codigo_empresa)

        lista = df_lista[colunas_base].copy()
        if col_empresa:
            lista["empresa"] = df_lista[col_empresa]
        else:
            lista["empresa"] = ""
        if col_nome:
            lista["nome"] = df_lista[col_nome]
        else:
            lista["nome"] = ""
        lista["codigo"] = df_lista[col_codigo]
        if col_codigo_empresa:
            lista["codigo_empresa"] = df_lista[col_codigo_empresa]
        else:
            lista["codigo_empresa"] = ""
        lista["empresa_key"] = lista["empresa"].apply(
            lambda v: self._normalizar_texto(v, remover_prefixo_numerico=True)
        )
        lista["codigo_empresa_key"] = lista["codigo_empresa"].apply(self._normalizar_codigo)
        lista["codigo_key"] = lista["codigo"].apply(self._normalizar_codigo)
        lista["nome_key"] = lista["nome"].apply(self._normalizar_texto)

        base = self.dados_consolidados.copy()
        base["empresa_key"] = base["Empresa"].apply(
            lambda v: self._normalizar_texto(v, remover_prefixo_numerico=True)
        )
        base["codigo_empresa_key"] = base["Código Empresa"].apply(self._normalizar_codigo)
        base["codigo_key"] = base["Código Empregado"].apply(self._normalizar_codigo)
        base["nome_key"] = base["Nome"].apply(self._normalizar_texto)

        if col_codigo_empresa:
            chaves = set(
                lista.apply(
                    lambda r: (r["codigo_empresa_key"], r["codigo_key"]),
                    axis=1,
                ).tolist()
            )
            mascara = base.apply(
                lambda r: (r["codigo_empresa_key"], r["codigo_key"]) in chaves,
                axis=1,
            )
        else:
            chaves = set(
                lista.apply(
                    lambda r: (r["empresa_key"], r["codigo_key"], r["nome_key"]),
                    axis=1,
                ).tolist()
            )
            mascara = base.apply(
                lambda r: (r["empresa_key"], r["codigo_key"], r["nome_key"]) in chaves,
                axis=1,
            )
        self.dados_consolidados.loc[mascara, "Status"] = status

    def processar_bloco(
        self, inicio: int, fim: int, empresa: str, cnpj: str, codigo_empresa: str
    ) -> pd.DataFrame:
        assert self.dados_raw is not None

        idx_cabecalho = self.extrair_cabecalho(inicio, fim)
        if idx_cabecalho is None:
            return pd.DataFrame()

        colunas_mapa = {
            "Código Empregado": 0,
            "Matricula eSocial": 4,
            "Nome": 6,
            "CPF": 9,
            "Competência": 12,
            "Remuneração": 14,
            "Pagamento": 17,
        }

        dados_bloco = self.dados_raw.iloc[idx_cabecalho + 1 : fim]

        df = pd.DataFrame(
            {
                nome_col: (
                    dados_bloco.iloc[:, idx_col]
                    if idx_col < dados_bloco.shape[1]
                    else np.nan
                )
                for nome_col, idx_col in colunas_mapa.items()
            }
        )

        df = df.dropna(how="all")
        df = df[~(df["Nome"].isna() & df["CPF"].isna())]
        df["CPF"] = df["CPF"].apply(self.formatar_cpf)
        df["Competência"] = df["Competência"].apply(self.formatar_competencia)

        df.insert(0, "Empresa", empresa if empresa else "")
        df.insert(1, "Código Empresa", codigo_empresa if codigo_empresa else "")
        df.insert(2, "CNPJ", cnpj if cnpj else "")

        df["Status"] = "Invalidado"

        return df

    def carregar_dados(self):
        self.dados_raw = pd.read_excel(self.arquivo_entrada, header=None, engine="openpyxl")

    def processar(self):
        self.carregar_dados()
        self.blocos_encontrados = self.identificar_blocos_empresa()

        resultados = []
        for i, inicio_bloco in enumerate(self.blocos_encontrados):
            fim_bloco = (
                self.blocos_encontrados[i + 1]
                if i + 1 < len(self.blocos_encontrados)
                else len(self.dados_raw)
            )

            empresa, cnpj, codigo_empresa = self.extrair_dados_empresa(inicio_bloco)
            df_bloco = self.processar_bloco(
                inicio_bloco, fim_bloco, empresa, cnpj, codigo_empresa
            )
            if not df_bloco.empty:
                resultados.append(df_bloco)

        if resultados:
            self.dados_consolidados = pd.concat(resultados, ignore_index=True)
            self.dados_consolidados["Status"] = self._calcular_status(self.dados_consolidados)
            self.dados_consolidados = self.dados_consolidados.sort_values(
                by=["Empresa", "Competência", "Nome"], na_position="last"
            ).reset_index(drop=True)
        else:
            self.dados_consolidados = pd.DataFrame()

    def calcular_estatisticas(self) -> Dict:
        if self.dados_consolidados.empty:
            return {
                "total_registros": 0,
                "total_validados": 0,
                "total_invalidados": 0,
                "total_afastados": 0,
                "total_pro_labore": 0,
                "total_domestica": 0,
                "percentual_validados": 0,
                "percentual_invalidados": 0,
                "percentual_afastados": 0,
                "percentual_pro_labore": 0,
                "percentual_domestica": 0,
                "total_empresas": 0,
                "total_funcionarios": 0,
                "competencias": [],
                "por_empresa": [],
            }

        df = self.dados_consolidados
        stats = {
            "total_registros": len(df),
            "total_validados": int((df["Status"] == "Validado").sum()),
            "total_invalidados": int((df["Status"] == "Invalidado").sum()),
            "total_afastados": int((df["Status"] == "Afastado").sum()),
            "total_pro_labore": int((df["Status"] == "Pro Labore").sum()),
            "total_domestica": int((df["Status"] == "Doméstica").sum()),
            "percentual_validados": round(
                (df["Status"] == "Validado").sum() / len(df) * 100, 2
            ),
            "percentual_invalidados": round(
                (df["Status"] == "Invalidado").sum() / len(df) * 100, 2
            ),
            "percentual_afastados": round(
                (df["Status"] == "Afastado").sum() / len(df) * 100, 2
            ),
            "percentual_pro_labore": round(
                (df["Status"] == "Pro Labore").sum() / len(df) * 100, 2
            ),
            "percentual_domestica": round(
                (df["Status"] == "Doméstica").sum() / len(df) * 100, 2
            ),
            "total_empresas": df["Empresa"].nunique(),
            "total_funcionarios": df["CPF"].nunique(),
            "competencias": sorted(df["Competência"].dropna().unique().tolist()),
            "por_empresa": [],
        }

        for empresa in df["Empresa"].unique():
            df_emp = df[df["Empresa"] == empresa]
            stats["por_empresa"].append(
                {
                    "nome": empresa,
                    "cnpj": df_emp["CNPJ"].iloc[0] if not df_emp.empty else "",
                    "total": len(df_emp),
                    "validados": int((df_emp["Status"] == "Validado").sum()),
                    "invalidados": int((df_emp["Status"] == "Invalidado").sum()),
                    "afastados": int((df_emp["Status"] == "Afastado").sum()),
                    "pro_labore": int((df_emp["Status"] == "Pro Labore").sum()),
                    "domestica": int((df_emp["Status"] == "Doméstica").sum()),
                    "percentual": round(
                        (df_emp["Status"] == "Validado").sum() / len(df_emp) * 100,
                        2,
                    ),
                }
            )

        self.estatisticas = stats
        return stats

    def exportar_excel(self, destino_saida):
        wb = Workbook()

        ws_dados = wb.active
        ws_dados.title = "Consolidado"

        for r_idx, row in enumerate(
            dataframe_to_rows(self.dados_consolidados, index=False, header=True), 1
        ):
            for c_idx, value in enumerate(row, 1):
                cell = ws_dados.cell(row=r_idx, column=c_idx, value=value)

                if r_idx == 1:
                    cell.font = Font(bold=True, color="FFFFFF", size=11)
                    cell.fill = PatternFill(
                        start_color="366092", end_color="366092", fill_type="solid"
                    )
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                elif c_idx == len(row):
                    if value == "Validado":
                        cell.fill = PatternFill(
                            start_color="C6EFCE", end_color="C6EFCE", fill_type="solid"
                        )
                        cell.font = Font(color="006100", bold=True)
                    elif value == "Invalidado":
                        cell.fill = PatternFill(
                            start_color="FFC7CE", end_color="FFC7CE", fill_type="solid"
                        )
                        cell.font = Font(color="9C0006", bold=True)
                    elif value == "Afastado":
                        cell.fill = PatternFill(
                            start_color="FFEB9C", end_color="FFEB9C", fill_type="solid"
                        )
                        cell.font = Font(color="9C6500", bold=True)
                    elif value == "Pro Labore":
                        cell.fill = PatternFill(
                            start_color="D9E1F2", end_color="D9E1F2", fill_type="solid"
                        )
                        cell.font = Font(color="1F4E78", bold=True)
                    elif value == "Doméstica":
                        cell.fill = PatternFill(
                            start_color="FCE4D6", end_color="FCE4D6", fill_type="solid"
                        )
                        cell.font = Font(color="7F4126", bold=True)
                    cell.alignment = Alignment(horizontal="center")

                cell.border = Border(
                    left=Side(style="thin", color="CCCCCC"),
                    right=Side(style="thin", color="CCCCCC"),
                    top=Side(style="thin", color="CCCCCC"),
                    bottom=Side(style="thin", color="CCCCCC"),
                )

        larguras = {
            "A": 35,
            "B": 20,
            "C": 15,
            "D": 15,
            "E": 35,
            "F": 15,
            "G": 12,
            "H": 15,
            "I": 15,
            "J": 15,
        }
        for col, largura in larguras.items():
            ws_dados.column_dimensions[col].width = largura

        ws_dados.freeze_panes = "A2"

        ws_stats = wb.create_sheet("Estatísticas")
        stats = self.calcular_estatisticas()

        ws_stats["A1"] = "ESTATÍSTICAS DO PROCESSAMENTO"
        ws_stats["A1"].font = Font(bold=True, size=14, color="FFFFFF")
        ws_stats["A1"].fill = PatternFill(
            start_color="366092", end_color="366092", fill_type="solid"
        )
        ws_stats.merge_cells("A1:C1")

        linha = 3
        ws_stats[f"A{linha}"] = "Total de Registros:"
        ws_stats[f"B{linha}"] = stats["total_registros"]
        ws_stats[f"A{linha}"].font = Font(bold=True)

        linha += 1
        ws_stats[f"A{linha}"] = "Validados:"
        ws_stats[f"B{linha}"] = stats["total_validados"]
        ws_stats[f"C{linha}"] = f"{stats['percentual_validados']}%"
        ws_stats[f"B{linha}"].fill = PatternFill(
            start_color="C6EFCE", end_color="C6EFCE", fill_type="solid"
        )

        linha += 1
        ws_stats[f"A{linha}"] = "Invalidados:"
        ws_stats[f"B{linha}"] = stats["total_invalidados"]
        ws_stats[f"C{linha}"] = f"{stats['percentual_invalidados']}%"
        ws_stats[f"B{linha}"].fill = PatternFill(
            start_color="FFC7CE", end_color="FFC7CE", fill_type="solid"
        )

        linha += 1
        ws_stats[f"A{linha}"] = "Afastados:"
        ws_stats[f"B{linha}"] = stats["total_afastados"]
        ws_stats[f"C{linha}"] = f"{stats['percentual_afastados']}%"
        ws_stats[f"B{linha}"].fill = PatternFill(
            start_color="FFEB9C", end_color="FFEB9C", fill_type="solid"
        )

        linha += 1
        ws_stats[f"A{linha}"] = "Pro Labore:"
        ws_stats[f"B{linha}"] = stats["total_pro_labore"]
        ws_stats[f"C{linha}"] = f"{stats['percentual_pro_labore']}%"
        ws_stats[f"B{linha}"].fill = PatternFill(
            start_color="D9E1F2", end_color="D9E1F2", fill_type="solid"
        )

        linha += 1
        ws_stats[f"A{linha}"] = "Doméstica:"
        ws_stats[f"B{linha}"] = stats["total_domestica"]
        ws_stats[f"C{linha}"] = f"{stats['percentual_domestica']}%"
        ws_stats[f"B{linha}"].fill = PatternFill(
            start_color="FCE4D6", end_color="FCE4D6", fill_type="solid"
        )

        linha += 2
        ws_stats[f"A{linha}"] = "Total de Empresas:"
        ws_stats[f"B{linha}"] = stats["total_empresas"]
        ws_stats[f"A{linha}"].font = Font(bold=True)

        linha += 1
        ws_stats[f"A{linha}"] = "Total de Funcionários:"
        ws_stats[f"B{linha}"] = stats["total_funcionarios"]
        ws_stats[f"A{linha}"].font = Font(bold=True)

        linha += 3
        ws_stats[f"A{linha}"] = "DETALHAMENTO POR EMPRESA"
        ws_stats[f"A{linha}"].font = Font(bold=True, size=12)
        ws_stats.merge_cells(f"A{linha}:E{linha}")

        linha += 1
        cabecalho = [
            "Empresa",
            "CNPJ",
            "Total",
            "Validados",
            "Invalidados",
            "Afastados",
            "Pro Labore",
            "Doméstica",
            "% Validados",
        ]
        for col, titulo in enumerate(cabecalho, 1):
            cell = ws_stats.cell(row=linha, column=col, value=titulo)
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill(
                start_color="366092", end_color="366092", fill_type="solid"
            )
            cell.alignment = Alignment(horizontal="center")

        for emp in stats["por_empresa"]:
            linha += 1
            ws_stats[f"A{linha}"] = emp["nome"]
            ws_stats[f"B{linha}"] = emp["cnpj"]
            ws_stats[f"C{linha}"] = emp["total"]
            ws_stats[f"D{linha}"] = emp["validados"]
            ws_stats[f"E{linha}"] = emp["invalidados"]
            ws_stats[f"F{linha}"] = emp["afastados"]
            ws_stats[f"G{linha}"] = emp["pro_labore"]
            ws_stats[f"H{linha}"] = emp["domestica"]
            ws_stats[f"I{linha}"] = f"{emp['percentual']}%"

        ws_stats.column_dimensions["A"].width = 40
        ws_stats.column_dimensions["B"].width = 20
        ws_stats.column_dimensions["C"].width = 12
        ws_stats.column_dimensions["D"].width = 12
        ws_stats.column_dimensions["E"].width = 12
        ws_stats.column_dimensions["F"].width = 15
        ws_stats.column_dimensions["G"].width = 15
        ws_stats.column_dimensions["H"].width = 15
        ws_stats.column_dimensions["I"].width = 15

        wb.save(destino_saida)
